$(document).ready(function(){
	
	var source = new EventSource("serviceweb/serviceweb");
	source.onmessage = function(event) {
		//var message = $.parseJSON(event.data);
		$("body").append("<div> [ " + event.data + " ] </div>")
	}
});