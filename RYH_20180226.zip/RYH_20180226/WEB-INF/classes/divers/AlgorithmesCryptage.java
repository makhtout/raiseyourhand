package divers;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
//Effecturer le chiffrement de mot de passe
public class AlgorithmesCryptage {

    static String IV = "AAAAAAAAAAAAAAAA";
    public static String encryptionKey = "mastergime20172018";

    public static String encoderEnMD5(String chaine) {
        byte[] uniqueKey = chaine.getBytes();
        byte[] hash = null;
        try {
            hash = MessageDigest.getInstance("MD5").digest(uniqueKey);
        } catch (NoSuchAlgorithmException e) {
            //log.fatal(e.getMessage());
        }
        StringBuilder hashString = new StringBuilder();
        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(hash[i]);
            if (hex.length() == 1) {
                hashString.append('0');
                hashString.append(hex.charAt(hex.length() - 1));
            } else {
                hashString.append(hex.substring(hex.length() - 2));
            }
        }
        return hashString.toString();
    }


    public static String encrypt(String plainText) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
        SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), "AES");
        cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(IV.getBytes("UTF-8")));
        byte[] resultat = cipher.doFinal(plainText.getBytes("UTF-8"));
        BigInteger msg = new BigInteger(resultat);
        return msg.toString();
    }

    public static String decrypt(String plainText) throws Exception {
        BigInteger msg = new BigInteger(plainText);
        byte[] cipherText = msg.toByteArray();
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
        SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), "AES");
        cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(IV.getBytes("UTF-8")));
        return new String(cipher.doFinal(cipherText), "UTF-8");
    }
//Ajout;String motpassHaches = AlgorithmesCryptage.encoderEnMD5(nouveauMotPasse);
    //Recuperation: String password = AlgorithmesCryptage.encoderEnMD5(password);
    
}



