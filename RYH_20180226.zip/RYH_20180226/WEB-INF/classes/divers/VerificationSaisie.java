package divers;
//Verifier la saisie de me mail et de mot de passe 
public class VerificationSaisie {
	public static boolean verifierMail(String email) {
		// TODO: Replace this with your own logic
		if (email.contains("@") == true) {
			String[] chaineTab = email.split("\\@");
			if (chaineTab.length == 2) {
				String sousChaine = chaineTab[1];
				String[] sousChaineTab = sousChaine.split("\\.");
				if (sousChaineTab.length >= 2) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
		return false;
	}

	public static boolean verifierMotPasse(String password) {
		return password.length() > 4;
	}

}
