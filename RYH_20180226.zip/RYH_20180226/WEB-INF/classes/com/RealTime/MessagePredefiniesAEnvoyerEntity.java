package com.RealTime;

public class MessagePredefiniesAEnvoyerEntity {

	private long idMessagePredefinies;
    private String libelleMessagePredfinies;
    private  String codeSalleVirtuelle;

    public MessagePredefiniesAEnvoyerEntity() {
    }

    public MessagePredefiniesAEnvoyerEntity(long idMessagePredefinies, String libelleMessagePredfinies, String codeSalleVirtuelle) {
        this.idMessagePredefinies = idMessagePredefinies;
        this.libelleMessagePredfinies = libelleMessagePredfinies;
        this.codeSalleVirtuelle = codeSalleVirtuelle;
    }

    public long getIdMessagePredefinies() {
        return idMessagePredefinies;
    }

    public void setIdMessagePredefinies(long idMessagePredefinies) {
        this.idMessagePredefinies = idMessagePredefinies;
    }

    public String getLibelleMessagePredfinies() {
        return libelleMessagePredfinies;
    }

    public void setLibelleMessagePredfinies(String libelleMessagePredfinies) {
        this.libelleMessagePredfinies = libelleMessagePredfinies;
    }

    public String getCodeSalleVirtuelle() {
        return codeSalleVirtuelle;
    }

    public void setCodeSalleVirtuelle(String codeSalleVirtuelle) {
        this.codeSalleVirtuelle = codeSalleVirtuelle;
    }

}
