package com.RealTime;

import java.util.HashSet;
import java.util.Set;

import org.glassfish.jersey.media.sse.SseFeature;

public class Application extends javax.ws.rs.core.Application{
	
	@Override
	public Set<Class<?>> getClasses() {
			return new HashSet<Class<?>>() {{
			
			add(SseFeature.class);
			add(Resource.class);
		}};
	}

}

