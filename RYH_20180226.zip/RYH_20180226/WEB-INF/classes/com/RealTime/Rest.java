package com.RealTime;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

@ApplicationPath("serviceweb")

public class Rest extends ResourceConfig  {
	
	public Rest() {
		
		 packages("com.fasterxml.jackson.jaxrs.json");
	     packages("com.RealTime");	
	     
	}

}
