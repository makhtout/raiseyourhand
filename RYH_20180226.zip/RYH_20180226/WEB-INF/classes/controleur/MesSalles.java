package controleur;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.SalleVirtuelleDao;

/**
 * Servlet implementation class MesSalles
 */
@WebServlet("/MesSalles")
public class MesSalles extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MesSalles() {
		super();
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("btn-Lancer") != null) {
			//Lancer la salle 
			String idSalle = request.getParameter("idSalle");
			request.setAttribute("idSalle", idSalle);
			this.getServletContext().getRequestDispatcher("/PresentationLancee").forward(request, response);
		} else if (request.getParameter("btn-Supprimer") != null) {
			//Supprimer la salle 
			String idSalleVirtuelle = request.getParameter("idSalle");
			try {
				SalleVirtuelleDao.supprimerSallerVirtuelle(Long.parseLong(idSalleVirtuelle));
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			response.sendRedirect("MesSalles.jsp");

		}

	}

}
