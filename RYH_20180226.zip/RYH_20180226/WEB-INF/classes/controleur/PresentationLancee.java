package controleur;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.MessagePredefini;
import beans.Question;
import beans.QuestionnaireLancee;
import beans.ReponseAuditoire;
import dao.LancementQuestionnaireDao;
import dao.MessagePredefiniDao;
import dao.QuestionDao;
import dao.ReponseAuditoireQuestionnaire;
import dao.ReponseProposerDao;
import dao.SalleVirtuelleDao;

/**
 * Servlet implementation class PresentationLancee
 */
@WebServlet("/PresentationLancee")
public class PresentationLancee extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// ArrayList<Questionnaire> listQuestionnaire;
	long idSalleVirtuelle;
	ArrayList<Question> listQuestion;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PresentationLancee() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Recuperation de l'idSalle et le convertir en Long
		String idSalle = (String) request.getAttribute("idSalle");

		if (idSalle != null) {
			idSalleVirtuelle = Long.parseLong(idSalle);
			try {
				// Selection des messages predefinis � partir de l'idSalle
				ArrayList<MessagePredefini> listMessagePredefiniesInitiale = MessagePredefiniDao
						.getAllMessagePredefinies(idSalleVirtuelle);

				String Cle = SalleVirtuelleDao.getCleById(idSalleVirtuelle);
				// Selection des questions � partir de l'idSalle
				listQuestion = QuestionDao.getAllQuestionsByIdSalleVirtuelle(idSalleVirtuelle);
				if (listQuestion != null) {
					// Redirection vers la PresentationEnCours.jsp avec la liste des questions et la
					// liste des messages pr�d�finies
					request.setAttribute("listQuestion", listQuestion);
					request.setAttribute("listMessagePredefinies", listMessagePredefiniesInitiale);
					this.getServletContext().getRequestDispatcher("/PresentationEnCours.jsp").forward(request,
							response);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			String idSalleVirtuelleDeQuestionnaire = request.getParameter("idSalleVirtuelle");
			String idQuestionDiffuser = request.getParameter("idQuestionDiff");
			// Si on a cliquer sur la boutton de diffusion on  obtient l'idSalle Diffusion et l'id de la question � diffuser
			if (idQuestionDiffuser != null && !idQuestionDiffuser.equals("")) {
				long idSalleVirtuelleAssoiceAuSalleLancee = Long.parseLong(idSalleVirtuelleDeQuestionnaire);
				long IdQuestionDiffuser = Long.parseLong(idQuestionDiffuser);
				if (request.getParameter("btn_diffuser") != null) {
					try {
						//On verifie si la question existe d�ja dans la table de lancement de question 
						boolean verifExistance = LancementQuestionnaireDao.verifExistance(IdQuestionDiffuser);
						
						ArrayList<MessagePredefini> listMessagePredefinies = MessagePredefiniDao
								.getAllMessagePredefinies(idSalleVirtuelleAssoiceAuSalleLancee);
						ArrayList<ReponseAuditoire> listReponseAuditoire = ReponseAuditoireQuestionnaire
								.getAllReponsesParIdQuestion(IdQuestionDiffuser);
						String Cle = SalleVirtuelleDao.getCleById(idSalleVirtuelle);
						listQuestion = QuestionDao.getAllQuestionsByIdSalleVirtuelle(idSalleVirtuelle);
						if (!verifExistance) {
							// Redirection vers la PresentationEnCours.jsp avec la liste des questions et la
							// liste des messages pr�d�finies
							LancementQuestionnaireDao.ajouterQuestionsLancee(idSalleVirtuelleAssoiceAuSalleLancee,
									IdQuestionDiffuser);
							request.setAttribute("listQuestion", listQuestion);
							request.setAttribute("listMessagePredefinies", listMessagePredefinies);
							this.getServletContext().getRequestDispatcher("/PresentationEnCours.jsp").forward(request,
									response);
						} else {
							request.setAttribute("listQuestion", listQuestion);
							request.setAttribute("listMessagePredefinies", listMessagePredefinies);
							this.getServletContext().getRequestDispatcher("/PresentationEnCours.jsp").forward(request,
									response);
						}

					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				// Si on a cliquer sur la boutton de supprimer on  obtient l'id de la question � supprim�

				if (request.getParameter("btn_Supprimer") != null) {
					//Obtention de question � supprim�
					long idQuestionSupprimer = Long.parseLong(idQuestionDiffuser);

					try {
						//Supprimer la question du BD question et des questions diffus�s
						QuestionDao.supprimerQuestionByIdQuestion(idQuestionSupprimer);
						LancementQuestionnaireDao.supprimerQuestionLanceeByIdQuestion(idQuestionSupprimer);
						// Redirection vers la PresentationEnCours.jsp avec la liste des questions et la
						// liste des messages pr�d�finies
						ArrayList<MessagePredefini> listMessagePredefinies = MessagePredefiniDao
								.getAllMessagePredefinies(idSalleVirtuelleAssoiceAuSalleLancee);
						ArrayList<Question> listQuestionAjour = QuestionDao
								.getAllQuestionsByIdSalleVirtuelle(idSalleVirtuelleAssoiceAuSalleLancee);
						request.setAttribute("listQuestion", listQuestionAjour);
						request.setAttribute("listMessagePredefinies", listMessagePredefinies);
						this.getServletContext().getRequestDispatcher("/PresentationEnCours.jsp").forward(request,
								response);
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}

	}
}
