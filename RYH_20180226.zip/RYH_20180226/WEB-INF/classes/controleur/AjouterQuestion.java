package controleur;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.sun.org.apache.bcel.internal.generic.LNEG;

import beans.Question;
import dao.QuestionDao;
import dao.ReponseProposerDao;

/**
 * Servlet implementation class AjouterQuestion
 */
@WebServlet("/AjouterQuestion")
public class AjouterQuestion extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Long idSalleVirtuelle;
	private ServletFileUpload uploader = null;
	Long idQuestion;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AjouterQuestion() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void init() throws ServletException {
		super.init();
		DiskFileItemFactory fileFactory = new DiskFileItemFactory();
		File filesDir = (File) getServletContext().getAttribute("FILES_DIR_FILE");
		fileFactory.setRepository(filesDir);
		this.uploader = new ServletFileUpload(fileFactory);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		// Obtenir l'id de la salle virtuelle a partir de session courante
		Long idSalleDisp = (Long) session.getAttribute("idSalleEnCoursDeCreation");
		// Initialiser les param�tres associ� aux param�tres issues de la page
		// Questionnaire.jsp
		String ressourceGraphique = null;
		String questionLib = null;
		String tousLesReponse = null;
		// Cr�er une instance de la classe question et on associe l'id de la salle aux
		// idSalle de la question
		Question questionO = new Question();
		questionO.setIdSalleVirtuelle(idSalleDisp);
		if (ServletFileUpload.isMultipartContent(request)) {
			try {
				List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
				for (FileItem item : multiparts) {
					// Verifier si les items corespond aux textes,checbox,radio,boutton,etc..,
					if (item.isFormField() && item != null) {
						// S'il est �gale � l'id textQuestion la chaine questionLib et on asscie cette
						// valeur aux libelleQuestion de l'objet questionO
						if (item.getFieldName().equals("textQuestion")) {
							questionLib = item.getString();
							questionO.setLibelleQuestion(questionLib);
						}
						// S'il est �gale � l'id reponses la chaine tousLesReponse puis on fait un
						// d�coupage de la chaine selon \n
						// et on ajoute les reponses aux BD Reponse avec le libelleQuestion et le
						// libelleReponses
						if (item.getFieldName().equals("reponses")) {
							tousLesReponse = item.getString();
							String[] listReponseDeQuestion = tousLesReponse.split("\n");
							for (int i = 0; i < listReponseDeQuestion.length; i++) {
								ReponseProposerDao.ajouterReponseProposer(questionLib, listReponseDeQuestion[i]);
							}

						}
						// S'il est �gale � l'id btnValiderQuestion on sera rederig� vers la page
						// Questionnaire.jsp pour ajouter une autre question
						if (item.getFieldName().equals("btnValiderQuestion")) {
							this.getServletContext().getRequestDispatcher("/Questionnaire.jsp").forward(request,
									response);

						}
						// S'il est �gale � l'id btn-Suivant on sera rederig� vers la page
						// selectionnerReponseJuste.jsp et l'ajout des questions est termin�
						// on passe donc � choisir le(s) bonne(s) r�ponses

						if (item.getFieldName().equals("btn-Suivant")) {
							request.setAttribute("idSalleDisp", idSalleDisp);
							this.getServletContext().getRequestDispatcher("/selectionnerReponseJuste.jsp")
									.forward(request, response);
						}
					}
					// Verifier si les items corespond � une importation de fichier (de n'importe
					// quelle type)
					if (!item.isFormField() && item != null) {
						if (item.getFieldName().equals("textRessource")) {
							// on extraire ici le nomdeFiciher et le type(.jpg,mp4,mp3,...
							String name = new File(item.getName()).getName();
							// Path correspond aux emplacement de stockage sous le serveur Appache
							String path = (String) request.getServletContext().getAttribute("FILES_DIR")
									+ File.separator;
							// cheminImages correspond aux emplacement exacte de fichier de stockage
							String cheminImages = path + name;
							if (!name.equals("")) {
								ressourceGraphique = name;
								// On effectue l'insertion de l'mage sous le serveur
								item.write(new File(cheminImages));
							} else {
								ressourceGraphique = "";
							}

						}
					}
				}
				// On ajoute la question aux BD des Question
				QuestionDao.ajouterQuestion(idSalleDisp, questionLib, ressourceGraphique);
			}

			catch (Exception ex) {

				request.setAttribute("message", "File Upload Failed due to " + ex);

			}

		}
	}
}
