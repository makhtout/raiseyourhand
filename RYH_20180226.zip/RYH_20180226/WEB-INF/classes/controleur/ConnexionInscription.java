package controleur;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import beans.*;
import dao.*;
import divers.AlgorithmesCryptage;
import divers.VerificationSaisie;

/**
 * Servlet implementation class ConnexionInscription
 */
@WebServlet("/ConnexionInscription")
public class ConnexionInscription extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ConnexionInscription() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Creation de la session
		HttpSession session = request.getSession();

		String fromConnexion = request.getParameter("fromConnexion");
		String fromInscription = request.getParameter("fromInscription");
		// Detection du formulaire d'inscription
		if (fromInscription != null) {
			// D�tection des param�tres � parir de formulaire
			String civilite = request.getParameter("civilite");
			String prenom = request.getParameter("form-first-name");
			String nom = request.getParameter("form-last-name");
			String mail = request.getParameter("form-email");
			String pseudo = request.getParameter("form-pseudo");
			String mdp = request.getParameter("form-password");
			String mdpConfirm = request.getParameter("form-confirm-password");
			Boolean verif = null;
			if (mdp != null && mdpConfirm != null) {
				//Verifier le saisie des mail,la confirmit� des mots de passes puis l'ins�rer en cryptage dans la BD  
				if (VerificationSaisie.verifierMotPasse(mdp) && VerificationSaisie.verifierMail(mail)
						&& mdp.equals(mdpConfirm)) {
					String mdpHachees = AlgorithmesCryptage.encoderEnMD5(mdp);
					verif = true;
					//Creation de l'instance util a partir des param�tres obtenu
					Utilisateur util = new Utilisateur(pseudo, civilite, nom, prenom, mail, mdpHachees);
					try {
						//Ajouter l'instance au BD Utilisateur
						UtilisateurDao.ajouterUtilisateur(util);
					} catch (SQLException e) {
						e.printStackTrace();
					}
				} else {
					verif = false;
				}
			}
			//Redirection vers la meme page pur effectuer l'authentification
			request.setAttribute("verifConnexion", verif);
			this.getServletContext().getRequestDispatcher("/ConnexionInscription.jsp").forward(request, response);

		}
		// Detection du formulaire de connexion
		if (fromConnexion != null) {
			//Obtention des pseudo et mot de passe
			String pseudo = request.getParameter("form-username-connexion");
			String mdp = request.getParameter("form-password-connexion");

			try {
				//Crypter le mot de passe saisie
				String motDepasse = AlgorithmesCryptage.encoderEnMD5(mdp);
				//Verifier l'utilisateur a partir de son psudo et so mot de passe
				Utilisateur util = UtilisateurDao.verifierUtilisateur(pseudo, motDepasse);
				//Verifier la connexion si l'utilisateur est nulle
				boolean verifierConnexion = (util == null);
				//Sinon
				if (!verifierConnexion) {
					//Ajouter  l'utilisateur aux session et redirection vers les salles d'utilisateur
					session.setAttribute("clientConnecte", util);
					response.sendRedirect("MesSalles.jsp");

				} 
				//S'il est nulle
				else {
					//Redirection vers ConnexionInscription.jsp et envoyer le boolean vers cette page 
					//pour affichier l'alert d'erreur
					boolean verifierAuthentification = false;
					request.setAttribute("verifierAuthentification", verifierAuthentification);
					this.getServletContext().getRequestDispatcher("/ConnexionInscription.jsp").forward(request,
							response);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}

}
