package controleur;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.SalleVirtuelle;
import beans.Utilisateur;

import dao.SalleVirtuelleDao;

/**
 * Servlet implementation class NomCle
 */
@WebServlet("/NomCle")
public class NomCle extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NomCle() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		String cle = request.getParameter("result");
		String nom = request.getParameter("NomSalle");
		long idSalleVirtuelle = 0;
		// Obtenion d'utilisateur connect� � partir de la session
		Utilisateur util = (Utilisateur) session.getAttribute("clientConnecte");
		// Creation de l'instance de salle
		SalleVirtuelle salle = new SalleVirtuelle(util.getIdUtilisateur(), nom, cle);

		try {
			// Ajout de la salle au BD salleVirtuelle
			SalleVirtuelleDao.ajouterSallerVirtuelle(salle);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// METhode get id salle by cle + recupere valeur + envoyer dans le requette
		try {
			idSalleVirtuelle = SalleVirtuelleDao.getIdSalleByCle(cle);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Redirection vers a selection et lajout es salles virtuelle
		request.setAttribute("idSalleVirtuelle", idSalleVirtuelle);
		this.getServletContext().getRequestDispatcher("/MessagePredefini.jsp").forward(request, response);

	}

}
