package controleur;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ReponseJusteDao;
import dao.ReponseProposerDao;

/**
 * Servlet implementation class ReponseJuste
 */
@WebServlet("/ReponseJuste")
public class ReponseJuste extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ReponseJuste() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("btn-validerReponseJuste") != null) {
			try {
				int nbQuestion = Integer.parseInt(request.getParameter("nbrQuestions"));
				for (int i = 0; i < nbQuestion; i++) {
					// on obtient l'id de chaque question
					long idQuestion = Long.parseLong(request.getParameter("idQuestion" + i));
					// on Obtient le(s) r�ponses justes de chaque question
					String[] reponseJust = request.getParameterValues("reponsejustedeQuestion" + i);
					if (reponseJust != null) {
						for (int j = 0; j < reponseJust.length; j++) {
							// On ajoute les r�ponses justes de chaque question
							ReponseJusteDao.ajouterReponseJuste(idQuestion, reponseJust[j].toString());
						}
					}
				}

			} catch (SQLException e) { // TODO Auto-generated catch block
				e.printStackTrace();
			}
			// Retour aux pages de la liste des salles de l'utilisateur
			response.sendRedirect("MesSalles.jsp");
		}
	}
}
