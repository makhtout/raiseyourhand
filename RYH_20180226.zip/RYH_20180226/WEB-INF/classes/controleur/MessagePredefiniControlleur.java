package controleur;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.MessagePredefini;
import dao.MessagePredefiniDao;

/**
 * Servlet implementation class MessagePredefini
 */
@WebServlet("/MessagePredefini")
public class MessagePredefiniControlleur extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String[] messagePredefinies;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Obtention des messagePredefinies ajout�s � partir des zones d'ajout dynamique
		String messages = request.getParameter("messagePredefinies");
		// D�couper les messages seon le retour � la ligne \n
		String[] messagePredefiniesDynamique = messages.split("\n");
		HttpSession session = request.getSession();
		// Obtention de message s�l�ctionn� statique
		messagePredefinies = request.getParameterValues("checkMesagePredefinies");
		long idSalleVirtuelle = Long.parseLong(request.getParameter("idSalleVirtuelle"));
		if (messagePredefinies != null) {
			// Ajout les messagePredefinies � partir de s�l�ction statique
			for (int i = 0; i < messagePredefinies.length; i++) {
				if (!messagePredefinies[i].equals("")) {
					String couleurMessagePredefini = "";
					MessagePredefini messagePredefini = new MessagePredefini(idSalleVirtuelle,
							messagePredefinies[i].toString(), couleurMessagePredefini);
				}
				try {

					MessagePredefiniDao.ajouterMessagePredefini(idSalleVirtuelle, messagePredefinies[i].toString());

				} catch (SQLException e) { // TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		if (messagePredefiniesDynamique != null && messagePredefiniesDynamique.length > 0) {
			// Ajout les messagePredefinies � partir de s�l�ction dynamique
			for (int i = 0; i < messagePredefiniesDynamique.length; i++) {
				MessagePredefini messagePredefini = new MessagePredefini(idSalleVirtuelle,
						messagePredefiniesDynamique[i].toString(), "");

				try {
					MessagePredefiniDao.ajouterMessagePredefini(idSalleVirtuelle,
							messagePredefiniesDynamique[i].toString());

				} catch (SQLException e) { // TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

		// Redirection vers l'ajout des questions
		if (messagePredefiniesDynamique != null || messagePredefinies != null) {
			request.setAttribute("idSalleVirtuelle", idSalleVirtuelle);
			session.setAttribute("idSalleEnCoursDeCreation", idSalleVirtuelle);
			this.getServletContext().getRequestDispatcher("/Questionnaire.jsp").forward(request, response);

		}
	}
}
