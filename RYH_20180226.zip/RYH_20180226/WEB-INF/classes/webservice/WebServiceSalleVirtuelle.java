package webservice;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import beans.Question;
import beans.ReponseProposer;
import beans.SalleVirtuelle;
import dao.QuestionDao;
import dao.ReponseProposerDao;
import dao.SalleVirtuelleDao;
//Les salles sous le  path de Application "restservices" /salles

@Path("salles")
public class WebServiceSalleVirtuelle {
	List<SalleVirtuelle> list;

	public WebServiceSalleVirtuelle() {
		list = new ArrayList<>();
	}
	//Sous restservices/salles/getAllSalles on accede au methode de selection de tous les salles de DAO Salles

	@GET
	@Path("getAllSalles")
	@Produces(MediaType.APPLICATION_JSON)
	public SalleVirtuelle[] getAllReponsesSalles() throws SQLException {
		list = SalleVirtuelleDao.getAllSalle();
		return (SalleVirtuelle[]) list.toArray(new SalleVirtuelle[list.size()]);
	}

}
