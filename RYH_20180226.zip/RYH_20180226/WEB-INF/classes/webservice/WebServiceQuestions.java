package webservice;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import beans.MessagePredefini;
import beans.Question;
import dao.LancementQuestionnaireDao;
import dao.MessagePredefiniDao;
import dao.QuestionDao;
import dao.SalleVirtuelleDao;
//Les Questions sous le  path de Application "restservices" /questions

@Path("questions")
public class WebServiceQuestions {
	List<Question> list;

	public WebServiceQuestions() {
		list = new ArrayList<>();
	}
	//Sous l'url restservices/questions/cleSalle on accede au methode de selection des questions lanc�s selon le cle de la salle	

	@GET
	@Path("getQuestionsParCleSalle/{cleSalle}")
	@Produces(MediaType.APPLICATION_JSON)
	public Question[] getAllQuestionLance(@PathParam("cleSalle") String cleSalle) throws SQLException {
		Long idSalle = SalleVirtuelleDao.getIdSalleByCle(cleSalle);
		list = LancementQuestionnaireDao.getAllQuestionsLancee(idSalle);
		return (Question[]) list.toArray(new Question[list.size()]);
	}

}