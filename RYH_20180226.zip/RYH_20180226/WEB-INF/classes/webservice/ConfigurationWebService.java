package webservice;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;
//les paths des web servies est restservices
@ApplicationPath("restservices")
public class ConfigurationWebService extends ResourceConfig {

	public ConfigurationWebService() {
		//Associer les packages des webService
		packages("com.fasterxml.jackson.jaxrs.json");
		packages("webservice");
	}

}

