package webservice;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import beans.Question;
import beans.ReponseAuditoire;
import dao.QuestionDao;
import dao.ReponseAuditoireQuestionnaire;
import dao.SalleVirtuelleDao;

@Path("reponsesAuditoire")
public class WebServiceReponseAuditoire {
	List<ReponseAuditoire> list;

	// Insertion des r�ponses �tudiant dans le tableau des r�ponses auditoire
	@POST
	@Path("insert")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public void insert(ReponseAuditoire reponseQuestionEtudiant) throws SQLException {
		ReponseAuditoireQuestionnaire.ajouterReponsesAuditoire(reponseQuestionEtudiant);
	}

}
