package webservice;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import beans.Question;
import beans.ReponseProposer;
import dao.LancementQuestionnaireDao;
import dao.QuestionDao;
import dao.ReponseProposerDao;
import dao.SalleVirtuelleDao;
//Les reponses sous le  path de Application "restservices" /reponses

@Path("reponses")

public class WebServiceReponsesPropose {
	List<ReponseProposer> list;

	public WebServiceReponsesPropose() {
		list = new ArrayList<>();
	}
	// Sous l'url restservices/reponses/cleSalle on accede au methode de selection
	// des reponses des questions lanc�s selon le cle de la salle

	@GET
	@Path("getReponseParCleSalle/{cleSalle}")
	@Produces(MediaType.APPLICATION_JSON)
	public ReponseProposer[] getAllReponsesProposes(@PathParam("cleSalle") String cleSalle) throws SQLException {
		Long idSalle = SalleVirtuelleDao.getIdSalleByCle(cleSalle);
		List<Question> listQuestion = LancementQuestionnaireDao.getAllQuestionsLancee(idSalle);
		for (int i = 0; i < listQuestion.size(); i++) {

			ArrayList<ReponseProposer> listReponsePropose = ReponseProposerDao
					.getAllReponseParLibelleQuestion(listQuestion.get(i).getLibelleQuestion());
			list.addAll(listReponsePropose);
		}
		return (ReponseProposer[]) list.toArray(new ReponseProposer[list.size()]);
	}
}
