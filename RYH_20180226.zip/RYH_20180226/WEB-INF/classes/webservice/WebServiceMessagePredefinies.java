package webservice;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import beans.MessagePredefini;
import dao.MessagePredefiniDao;
import dao.SalleVirtuelleDao;
//Les MessagePredefinies sous le  path de Application "restservices" /messagespredefinies
@Path("messagespredefinies")

public class WebServiceMessagePredefinies {
	List<MessagePredefini> list;

	public WebServiceMessagePredefinies() {
		list = new ArrayList<>();
	}
	
	//Sous restservices/messagespredefinies/getAll on accede au methode de selection de tous les messages predefinies de DAO MessagePredefinies
	@GET
	@Path("getAll")
	@Produces(MediaType.APPLICATION_JSON)
	public MessagePredefini[] getAllMessagePredefinies() throws SQLException {

		list = MessagePredefiniDao.getAllMessagePredefiniesA();
		return (MessagePredefini[]) list.toArray(new MessagePredefini[list.size()]);
	}
	//Sous restservices/messagespredefinies/cleSalle on accede au methode de selection des messages predefinies selon le cle de la salle	
	@GET
	@Path("getParCleSalle/{cleSalle}")
	@Produces(MediaType.APPLICATION_JSON)
	public MessagePredefini[] getAllMessagePredefinies(@PathParam("cleSalle") String   cleSalle) throws SQLException {
		long idSalle=SalleVirtuelleDao.getIdSalleByCle(cleSalle);
		list = MessagePredefiniDao.getAllMessagePredefinies(idSalle);
		return (MessagePredefini[]) list.toArray(new MessagePredefini[list.size()]);
	}	
}
