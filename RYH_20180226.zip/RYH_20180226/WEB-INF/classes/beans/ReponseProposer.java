package beans;

public class ReponseProposer {

	private long idReponseProposer;
	private String libelleQuestion;
	private String libelleReponseProposer;

	public ReponseProposer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReponseProposer(long idReponseProposer, String libelleQuestion, String libelleReponseProposer) {
		super();
		this.idReponseProposer = idReponseProposer;
		this.libelleQuestion = libelleQuestion;
		this.libelleReponseProposer = libelleReponseProposer;
	}

	public long getIdReponseProposer() {
		return idReponseProposer;
	}

	public void setIdReponseProposer(long idReponseProposer) {
		this.idReponseProposer = idReponseProposer;
	}

	public String getLibelleQuestion() {
		return libelleQuestion;
	}

	public void setLibelleQuestion(String libelleQuestion) {
		this.libelleQuestion = libelleQuestion;
	}

	public String getLibelleReponseProposer() {
		return libelleReponseProposer;
	}

	public void setLibelleReponseProposer(String libelleReponseProposer) {
		this.libelleReponseProposer = libelleReponseProposer;
	}

	
}
