package beans;

public class MessagePredefini {
	
	long idMessagePredefini;
	long idSalleVirtuelle;
	String libelleMessagePredefini ; 
	String couleurMessagePredefini;
	
	public MessagePredefini() {
		super();
	}
	public MessagePredefini(long idMessagePredefini, long idSalleVirtuelle, String libelleMessagePredefini, String couleurMessagePredefini) {
		
		this.idMessagePredefini = idMessagePredefini;
		this.idSalleVirtuelle = idSalleVirtuelle;
		this.libelleMessagePredefini = libelleMessagePredefini;
		this.couleurMessagePredefini = couleurMessagePredefini;
	}
	

	public MessagePredefini(long idSalleVirtuelle, String libelleMessagePredefini, String couleurMessagePredefini) {
		
		this.idSalleVirtuelle = idSalleVirtuelle;
		this.libelleMessagePredefini = libelleMessagePredefini;
		this.couleurMessagePredefini = couleurMessagePredefini;
	}

	public long getIdSalleVirtuelle() {
		return idSalleVirtuelle;
	}

	public void setIdSalleVirtuelle(long idSalleVirtuelle) {
		this.idSalleVirtuelle = idSalleVirtuelle;
	}

	public long getIdMessagePredefini() {
		return idMessagePredefini;
	}

	public void setIdMessagePredefini(long idMessagePredefini) {
		this.idMessagePredefini = idMessagePredefini;
	}

	public String getLibelleMessagePredefini() {
		return libelleMessagePredefini;
	}

	public void setLibelleMessagePredefini(String libelleMessagePredefini) {
		this.libelleMessagePredefini = libelleMessagePredefini;
	}

	public String getCouleurMessagePredefini() {
		return couleurMessagePredefini;
	}

	public void setCouleurMessagePredefini(String couleurMessagePredefini) {
		this.couleurMessagePredefini = couleurMessagePredefini;
	}

	
	
}
