package beans;

public class Question {
	
	private long idQuestion;
	private String libelleQuestion;
	long idSalleVirtuelle;
	String ressourceGraphique;

	
	public Question() {
		super();
	}


	public Question(long idQuestion, String libelleQuestion, long idSalleVirtuelle, String ressourceGraphique) {
		super();
		this.idQuestion = idQuestion;
		this.libelleQuestion = libelleQuestion;
		this.idSalleVirtuelle = idSalleVirtuelle;
		this.ressourceGraphique = ressourceGraphique;
	}


	public long getIdQuestion() {
		return idQuestion;
	}


	public void setIdQuestion(long idQuestion) {
		this.idQuestion = idQuestion;
	}


	public String getLibelleQuestion() {
		return libelleQuestion;
	}


	public void setLibelleQuestion(String libelleQuestion) {
		this.libelleQuestion = libelleQuestion;
	}


	public long getIdSalleVirtuelle() {
		return idSalleVirtuelle;
	}


	public void setIdSalleVirtuelle(long idSalleVirtuelle) {
		this.idSalleVirtuelle = idSalleVirtuelle;
	}


	public String getRessourceGraphique() {
		return ressourceGraphique;
	}


	public void setRessourceGraphique(String ressourceGraphique) {
		this.ressourceGraphique = ressourceGraphique;
	}
	

	

}
