package beans;

public class SalleVirtuelle {
	
	private long idSalleVirtuelle ; 
	private long idUtilisateur ; 
	private String nomSalle ; 
	private String cleAccees ;
	
	public SalleVirtuelle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SalleVirtuelle(long idSalleVirtuelle, long idUtilisateur, String nomSalle, String cleAccees) {
		this.idSalleVirtuelle = idSalleVirtuelle;
		this.idUtilisateur = idUtilisateur;
		this.nomSalle = nomSalle;
		this.cleAccees = cleAccees;
	}

	public SalleVirtuelle( long idUtilisateur, String nomSalle, String cleAccees) {
		this.idUtilisateur = idUtilisateur;
		this.nomSalle = nomSalle;
		this.cleAccees = cleAccees;
	}
	public long getIdSalleVirtuelle() {
		return idSalleVirtuelle;
	}

	public void setIdSalleVirtuelle(long idSalleVirtuelle) {
		this.idSalleVirtuelle = idSalleVirtuelle;
	}

	public long getIdUtilisateur() {
		return idUtilisateur;
	}

	public void setIdUtilisateur(long idUtilisateur) {
		this.idUtilisateur = idUtilisateur;
	}

	public String getNomSalle() {
		return nomSalle;
	}

	public void setNomSalle(String nomSalle) {
		this.nomSalle = nomSalle;
	}

	public String getCleAccees() {
		return cleAccees;
	}

	public void setCleAccees(String cleAccees) {
		this.cleAccees = cleAccees;
	} 
	
	
	

}
