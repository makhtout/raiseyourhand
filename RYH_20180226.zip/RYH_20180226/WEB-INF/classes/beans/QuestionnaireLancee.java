package beans;

public class QuestionnaireLancee {
	private long idQuestionnaireLancee;
	private long idSalleVirtuelle;
	private long idQuestionnaire;

	public QuestionnaireLancee() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public QuestionnaireLancee(long idQuestionnaireLancee, long idSalleVirtuelle, long idQuestionnaire) {
		super();
		this.idQuestionnaireLancee = idQuestionnaireLancee;
		this.idSalleVirtuelle = idSalleVirtuelle;
		this.idQuestionnaire = idQuestionnaire;
	}



	public long getIdQuestionnaireLancee() {
		return idQuestionnaireLancee;
	}

	public void setIdQuestionnaireLancee(long idQuestionnaireLancee) {
		this.idQuestionnaireLancee = idQuestionnaireLancee;
	}

	public long getIdSalleVirtuelle() {
		return idSalleVirtuelle;
	}

	public void setIdSalleVirtuelle(long idSalleVirtuelle) {
		this.idSalleVirtuelle = idSalleVirtuelle;
	}

	public long getIdQuestionnaire() {
		return idQuestionnaire;
	}

	public void setIdQuestionnaire(long idQuestionnaire) {
		this.idQuestionnaire = idQuestionnaire;
	}



}
