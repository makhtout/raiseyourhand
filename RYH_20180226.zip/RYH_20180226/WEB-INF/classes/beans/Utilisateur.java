package beans;

public class Utilisateur {

	
	    private long idUtilisateur;
	    private String civiliteUtilisateur;
	    private String pseudoUtilisateur;
	    private String nomUtilisateur;
	    private String prenomUtilisateur;
	    private String mailUtilisateur;
	    private String mdpUtilisateur;
	    
	    
	    
	    

	    public Utilisateur() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
		public Utilisateur( String pseudoUtilisateur, String civiliteUtilisateur, String nomUtilisateur, String prenomUtilisateur, String mailUtilisateur, String mdpUtilisateur) {
	        this.pseudoUtilisateur = pseudoUtilisateur;
	        this.civiliteUtilisateur = civiliteUtilisateur;
	        this.nomUtilisateur = nomUtilisateur;
	        this.prenomUtilisateur = prenomUtilisateur;
	        this.mailUtilisateur = mailUtilisateur;
	        this.mdpUtilisateur = mdpUtilisateur;
	    }

		public Utilisateur(long idUtilisateur, String pseudoUtilisateur, String civiliteUtilisateur, String nomUtilisateur, String prenomUtilisateur, String mailUtilisateur, String mdpUtilisateur) {
	        this.idUtilisateur = idUtilisateur;
	        this.pseudoUtilisateur = pseudoUtilisateur;
	        this.civiliteUtilisateur = civiliteUtilisateur;
	        this.nomUtilisateur = nomUtilisateur;
	        this.prenomUtilisateur = prenomUtilisateur;
	        this.mailUtilisateur = mailUtilisateur;
	        this.mdpUtilisateur = mdpUtilisateur;
	    }

	    public long getIdUtilisateur() {
	        return idUtilisateur;
	    }

	    public void setIdUtilisateur(long idUtilisateur) {
	        this.idUtilisateur = idUtilisateur;
	    }

	    public String getPseudoUtilisateur() {
	        return pseudoUtilisateur;
	    }

	    public void setPseudoUtilisateur(String pseudoUtilisateur) {
	        this.pseudoUtilisateur = pseudoUtilisateur;
	    }

	    public String getCiviliteUtilisateur() {
	        return civiliteUtilisateur;
	    }

	    public void setCiviliteUtilisateur(String civiliteUtilisateur) {
	        this.civiliteUtilisateur = civiliteUtilisateur;
	    }

	    public String getNomUtilisateur() {
	        return nomUtilisateur;
	    }

	    public void setNomUtilisateur(String nomUtilisateur) {
	        this.nomUtilisateur = nomUtilisateur;
	    }

	    public String getPrenomUtilisateur() {
	        return prenomUtilisateur;
	    }

	    public void setPrenomUtilisateur(String prenomUtilisateur) {
	        this.prenomUtilisateur = prenomUtilisateur;
	    }

	    public String getLoginUtilisateur() {
	        return mailUtilisateur;
	    }

	    public void setLoginUtilisateur(String loginUtilisateur) {
	        this.mailUtilisateur = loginUtilisateur;
	    }

	    public String getMdpUtilisateur() {
	        return mdpUtilisateur;
	    }

	    public void setMdpUtilisateur(String mdpUtilisateur) {
	        this.mdpUtilisateur = mdpUtilisateur;
	    }
	    
	    

	    public String getMailUtilisateur() {
			return mailUtilisateur;
		}

		public void setMailUtilisateur(String mailUtilisateur) {
			this.mailUtilisateur = mailUtilisateur;
		}

		@Override
	    public boolean equals(Object o) {
	        if (this == o) return true;
	        if (o == null || getClass() != o.getClass()) return false;

	        Utilisateur that = (Utilisateur) o;

	        if (idUtilisateur != that.idUtilisateur) return false;
	        if (pseudoUtilisateur != null ? !pseudoUtilisateur.equals(that.pseudoUtilisateur) : that.pseudoUtilisateur != null)
	            return false;
	        if (civiliteUtilisateur != null ? !civiliteUtilisateur.equals(that.civiliteUtilisateur) : that.civiliteUtilisateur != null)
	            return false;
	        if (nomUtilisateur != null ? !nomUtilisateur.equals(that.nomUtilisateur) : that.nomUtilisateur != null)
	            return false;
	        if (prenomUtilisateur != null ? !prenomUtilisateur.equals(that.prenomUtilisateur) : that.prenomUtilisateur != null)
	            return false;
	        if (mailUtilisateur != null ? !mailUtilisateur.equals(that.mailUtilisateur) : that.mailUtilisateur != null)
	            return false;
	        return mdpUtilisateur != null ? mdpUtilisateur.equals(that.mdpUtilisateur) : that.mdpUtilisateur == null;
	    }

	    @Override
	    public int hashCode() {
	        int result = (int) (idUtilisateur ^ (idUtilisateur >>> 32));
	        result = 31 * result + (pseudoUtilisateur != null ? pseudoUtilisateur.hashCode() : 0);
	        result = 31 * result + (civiliteUtilisateur != null ? civiliteUtilisateur.hashCode() : 0);
	        result = 31 * result + (nomUtilisateur != null ? nomUtilisateur.hashCode() : 0);
	        result = 31 * result + (prenomUtilisateur != null ? prenomUtilisateur.hashCode() : 0);
	        result = 31 * result + (mailUtilisateur != null ? mailUtilisateur.hashCode() : 0);
	        result = 31 * result + (mdpUtilisateur != null ? mdpUtilisateur.hashCode() : 0);
	        return result;
	    }
	


}
