package beans;

/**
 * Created by zied on 25/01/2018.
 */

public class ReponseAuditoire {
	  private long idReponseAuditoire;
	    private long idQuestion;
	    private String reponseQuestion;
	    private String codeSalleVirtuelle;

    public ReponseAuditoire() {
    }

	public ReponseAuditoire(long idReponseAuditoire, long idQuestion, String reponseQuestion,
			String codeSalleVirtuelle) {
		super();
		this.idReponseAuditoire = idReponseAuditoire;
		this.idQuestion = idQuestion;
		this.reponseQuestion = reponseQuestion;
		this.codeSalleVirtuelle = codeSalleVirtuelle;
	}

	public long getIdReponseAuditoire() {
		return idReponseAuditoire;
	}

	public void setIdReponseAuditoire(long idReponseAuditoire) {
		this.idReponseAuditoire = idReponseAuditoire;
	}

	public long getIdQuestion() {
		return idQuestion;
	}

	public void setIdQuestion(long idQuestion) {
		this.idQuestion = idQuestion;
	}

	public String getReponseQuestion() {
		return reponseQuestion;
	}

	public void setReponseQuestion(String reponseQuestion) {
		this.reponseQuestion = reponseQuestion;
	}

	public String getCodeSalleVirtuelle() {
		return codeSalleVirtuelle;
	}

	public void setCodeSalleVirtuelle(String codeSalleVirtuelle) {
		this.codeSalleVirtuelle = codeSalleVirtuelle;
	}

	

	

	

}
