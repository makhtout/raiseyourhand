package beans;

public class ReponseJuste {
	
	private long idReponseJuste;
	private long idQuestion;
	private String libelleReponseJuste;
	
	
	public ReponseJuste() {
		super();
		// TODO Auto-generated constructor stub
	}


	public ReponseJuste(long idReponseJuste, long idQuestion, String libelleReponseJuste) {
		this.idReponseJuste = idReponseJuste;
		this.idQuestion = idQuestion;
		this.libelleReponseJuste = libelleReponseJuste;
	}


	public long getIdReponseJuste() {
		return idReponseJuste;
	}


	public void setIdReponseJuste(long idReponseJuste) {
		this.idReponseJuste = idReponseJuste;
	}


	public long getIdQuestion() {
		return idQuestion;
	}


	public void setIdQuestion(long idQuestion) {
		this.idQuestion = idQuestion;
	}


	public String getLibelleReponseJuste() {
		return libelleReponseJuste;
	}


	public void setLibelleReponseJuste(String libelleReponseJuste) {
		this.libelleReponseJuste = libelleReponseJuste;
	}
	
	
	
	

}
