package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import beans.ReponseProposer;

public class ReponseProposerDao {
//Ajout des reponses propos� d'une question
	public static void ajouterReponseProposer(String libelleQuestion, String libelleReponseProposer) throws SQLException {
		Connection conn = Connexion.getConnection();
		String insertTableSQL = "INSERT INTO reponseProposer" + "(libelleQuestion, libelleReponseProposer) VALUES" + "(?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(insertTableSQL);
		preparedStatement.setString(1, libelleQuestion);
		preparedStatement.setString(2, libelleReponseProposer);
		preparedStatement.executeUpdate();

	}
	//Obtenir les reponses d'une question � partir son libelle
	public static ArrayList<ReponseProposer> getAllReponseParLibelleQuestion(String libelleQuestion) throws SQLException {
		ArrayList<ReponseProposer> listReponsePropose = new ArrayList<>();
		Connection conn = Connexion.getConnection();
		String sql = "select * from reponseproposer where libelleQuestion = ? ;";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, libelleQuestion);
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {
			ReponseProposer reponseProposer = new ReponseProposer();
			reponseProposer.setIdReponseProposer(rs.getLong(1));
			reponseProposer.setLibelleQuestion(rs.getString(2));
			reponseProposer.setLibelleReponseProposer(rs.getString(3));
			listReponsePropose.add(reponseProposer);
		}
		return listReponsePropose;
	}

}
