package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import beans.Question;
import beans.ReponseAuditoire;
import beans.ReponseJuste;

public class ReponseAuditoireQuestionnaire {
	// Ajout des R�ponse auditoire
	public static void ajouterReponsesAuditoire(ReponseAuditoire reponseAuditoire) throws SQLException {

		Connection conn = Connexion.getConnection();

		String insertTableSQL = "INSERT INTO reponseauditoire"
				+ "(idQuestion, reponseQuestion, codeSalleVirtuelle) VALUES" + "(?,?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(insertTableSQL);
		preparedStatement.setLong(1, reponseAuditoire.getIdQuestion());
		preparedStatement.setString(2, reponseAuditoire.getReponseQuestion());
		preparedStatement.setString(3, reponseAuditoire.getCodeSalleVirtuelle());
		preparedStatement.executeUpdate();

	}

	// Obtenir les reponses des auditoires � un question
	public static ArrayList<ReponseAuditoire> getAllReponsesParIdQuestion(long idQuestion) throws SQLException {

		ArrayList<ReponseAuditoire> list = new ArrayList<>();
		Connection conn = Connexion.getConnection();
		String sql = "select * from reponseauditoire where idQuestion =? ;";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setLong(1, idQuestion);
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {
			ReponseAuditoire p = new ReponseAuditoire();
			p.setIdQuestion(rs.getLong(2));
			p.setReponseQuestion(rs.getString(3));
			p.setCodeSalleVirtuelle(rs.getString(4));
			list.add(p);
		}

		return list;

	}

	// calculer le nombre des auditoires qui ont repondu a une question par la
	// reponseSelection�
	public static Integer getCountQuestion(String reponseSelection�, long idQuestion) throws SQLException {
		int c = 0;
		Connection conn = Connexion.getConnection();

		String selectSQL = "SELECT COUNT(*) as count FROM reponseauditoire WHERE reponseQuestion = ?  and idQuestion=?";
		PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
		preparedStatement.setString(1, reponseSelection�);
		preparedStatement.setLong(2, idQuestion);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			c = rs.getInt("count");
		}
		return c;
	}
}
