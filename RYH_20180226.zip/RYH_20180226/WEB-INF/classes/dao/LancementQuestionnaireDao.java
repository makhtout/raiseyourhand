package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import beans.MessagePredefini;
import beans.Question;
import beans.QuestionnaireLancee;

public class LancementQuestionnaireDao {
	// Methode de lancement d'une question
	public static void ajouterQuestionsLancee(long idSalleVirtuelle, long idQuestion) throws SQLException {

		Connection conn = Connexion.getConnection();

		String insertTableSQL = "INSERT INTO questionnairelancee" + "(idSalleVirtuelle, idQuestion) VALUES" + "(?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(insertTableSQL);
		preparedStatement.setLong(1, idSalleVirtuelle);
		preparedStatement.setLong(2, idQuestion);
		preparedStatement.executeUpdate();

	}

	// Methode permet d'obtenir la questionLanc� a partir de l'id de question
	public static QuestionnaireLancee getQuestionnaireByIdQuestion(long idQuestion) throws SQLException {

		Connection conn = Connexion.getConnection();
		String sql = " SELECT * from questionnairelancee WHERE idQuestion=?";

		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setLong(1, idQuestion);
		ResultSet rs = preparedStatement.executeQuery();

		QuestionnaireLancee questionnaireLancee = new QuestionnaireLancee();
		while (rs.next()) {
			questionnaireLancee.setIdQuestionnaireLancee(rs.getLong(1));
			questionnaireLancee.setIdQuestionnaire(rs.getLong(2));
			questionnaireLancee.setIdSalleVirtuelle(rs.getLong(3));
		}
		return questionnaireLancee;
	}

	// Methode permet d'obtenir les questions Lanc� dans une salle virtuelle
	public static ArrayList<Question> getAllQuestionsLancee(long idSalle) throws SQLException {
		ArrayList<Question> list = new ArrayList<>();
		Connection conn = Connexion.getConnection();
		String sql = "select * from question where idQuestion in(SELECT idQuestion from questionnairelancee WHERE idSalleVirtuelle=?)";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setLong(1, idSalle);
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {
			Question p = new Question();
			p.setIdQuestion(rs.getLong(1));
			p.setIdSalleVirtuelle(rs.getLong(2));
			p.setLibelleQuestion(rs.getString(3));
			p.setRessourceGraphique(rs.getString(4));
			list.add(p);
		}
		return list;
	}

	// Verifi� l'extance d'une question dans les questions d�ja lanc�
	public static boolean verifExistance(long idQuestion) throws SQLException {
		int size = 0;
		Connection conn = Connexion.getConnection();
		String sql = " SELECT * from questionnairelancee WHERE idQuestion=?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setLong(1, idQuestion);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			size++;
		}
		boolean verif = (size == 1);
		return verif;
	}

	// M�thode de suppression de question dans les questions lanc�
	public static void supprimerQuestionLanceeByIdQuestion(long idQuestion) throws SQLException {
		String deleteSQL = "DELETE from questionnairelancee WHERE idQuestion = ?";
		Connection conn = Connexion.getConnection();
		PreparedStatement preparedStatement = conn.prepareStatement(deleteSQL);
		preparedStatement.setLong(1, idQuestion);
		preparedStatement.executeUpdate();
	}

}
