package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import beans.*;

public class SalleVirtuelleDao {
//Ajout d'une salle virtuelle
	public static void ajouterSallerVirtuelle(SalleVirtuelle salle) throws SQLException {

		Connection conn = Connexion.getConnection();

		String insertTableSQL = "INSERT INTO salleVirtuelle" + "(idUtilisateur, nomSalle, cleAccees) VALUES"
				+ "(?,?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(insertTableSQL);
		preparedStatement.setLong(1, salle.getIdUtilisateur());
		preparedStatement.setString(2, salle.getNomSalle());
		preparedStatement.setString(3, salle.getCleAccees());
		preparedStatement.executeUpdate();
	}

	public static void supprimerSallerVirtuelle(long idSalleVirtuelle) throws SQLException {
		Connection conn = Connexion.getConnection();
		Statement ps = conn.createStatement();
		String sql = "delete from sallevirtuelle where idSalleVirtuelle ='" + idSalleVirtuelle + "' ;";
		ps.executeUpdate(sql);

	}
//Metode d'obtention d'idSalle par son cl� 
	public static long getIdSalleByCle(String cleAccees) throws SQLException {

		Connection conn = Connexion.getConnection();
		String selectSQL = "SELECT idSalleVirtuelle FROM sallevirtuelle WHERE cleAccees = ? ";
		PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
		preparedStatement.setString(1, cleAccees);
		ResultSet rs = preparedStatement.executeQuery();
		SalleVirtuelle p = new SalleVirtuelle();

		while (rs.next()) {

			p.setIdSalleVirtuelle(rs.getLong(1));

		}
		return p.getIdSalleVirtuelle();

	}
	//Metode d'obtention de cl� de la salle par son id 
	public static String getCleById(long idSalle) throws SQLException {

		Connection conn = Connexion.getConnection();
		String selectSQL = "SELECT * FROM sallevirtuelle WHERE idSalleVirtuelle = ? ";
		PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
		preparedStatement.setLong(1, idSalle);
		ResultSet rs = preparedStatement.executeQuery();

		SalleVirtuelle p = new SalleVirtuelle();

		while (rs.next()) {

			p.setCleAccees(rs.getString(4));

		}
		return p.getCleAccees();

	}
//Methode d'obtention de tous les salles virtulles d'un utilisateur � partir son id
	public static ArrayList<SalleVirtuelle> getListSalleByIdUtilisateur(long idUtilisateur) throws SQLException {

		ArrayList<SalleVirtuelle> lesSalles = new ArrayList<>();

		Connection conn = Connexion.getConnection();
		String selectSQL = "SELECT * FROM sallevirtuelle WHERE idUtilisateur = ? ";
		PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
		preparedStatement.setLong(1, idUtilisateur);
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {

			SalleVirtuelle salle = new SalleVirtuelle();
			salle.setIdSalleVirtuelle(rs.getLong(1));
			salle.setIdUtilisateur(rs.getLong(2));
			salle.setNomSalle(rs.getString(3));
			salle.setCleAccees(rs.getString(4));
			lesSalles.add(salle);

		}
		return lesSalles;
	}
//Obtenir tous les salles
	public static ArrayList<SalleVirtuelle> getAllSalle() throws SQLException {


		ArrayList<SalleVirtuelle> lesSalles = new ArrayList<>();

		Connection conn = Connexion.getConnection();
		String selectSQL = "SELECT * FROM sallevirtuelle  ";
		PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {

			SalleVirtuelle salle = new SalleVirtuelle();
			salle.setIdSalleVirtuelle(rs.getLong(1));
			salle.setIdUtilisateur(rs.getLong(2));
			salle.setNomSalle(rs.getString(3));
			salle.setCleAccees(rs.getString(4));
			lesSalles.add(salle);

		}
		return lesSalles;
}
}
