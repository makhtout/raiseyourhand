package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import beans.MessagePredefini;
import beans.ReponseProposer;

public class MessagePredefiniDao {
	// Ajout des message Predefinies et g�n�ration des couleur selon le
	// libelleDesMessage
	public static void ajouterMessagePredefini(long idSalleVirtuelle, String libelleMessagePredefini)
			throws SQLException {

		Connection conn = Connexion.getConnection();
		Statement ps = conn.createStatement();
		String couleurMessagePredefini = "";

		if (libelleMessagePredefini.equals("Bravo")) {
			couleurMessagePredefini += "btn btn-success";
		}
		if (libelleMessagePredefini.equals("Merci")) {
			couleurMessagePredefini += "btn btn-info";
		}
		if (libelleMessagePredefini.equals("Parlez plus fort !")) {
			couleurMessagePredefini += "btn btn-warning";
		}
		if (libelleMessagePredefini.equals("Pas compris !")) {
			couleurMessagePredefini += "btn btn-danger";
		}
		if (libelleMessagePredefini.equals("Repeter ce point !")) {
			couleurMessagePredefini += "btn btn-warning";
		}
		if (libelleMessagePredefini.equals("Diapo non visible")) {
			couleurMessagePredefini += "btn btn-warning";
		}
		if (couleurMessagePredefini.equals("")) {
			couleurMessagePredefini += "btn btn-default";
		}
		if (libelleMessagePredefini != null && !libelleMessagePredefini.equals("")) {
			String insertTableSQL = "INSERT INTO messagePredefini"
					+ "(idSalleVirtuelle, libelleMessagePredefini, couleurMessagePredefini) VALUES" + "(?,?,?)";
			PreparedStatement preparedStatement = conn.prepareStatement(insertTableSQL);
			preparedStatement.setLong(1, idSalleVirtuelle);
			preparedStatement.setString(2, libelleMessagePredefini);
			preparedStatement.setString(3, couleurMessagePredefini);
			preparedStatement.executeUpdate();
		}
	}
//Metode permet de retouner tous les message pr�definies
	public static ArrayList<MessagePredefini> getAllMessagePredefiniesA() throws SQLException {
		ArrayList<MessagePredefini> list = new ArrayList<>();
		Connection conn = Connexion.getConnection();
		PreparedStatement ps = conn.prepareStatement("select * from messagePredefini;");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			MessagePredefini messagePredefinies = new MessagePredefini();
			messagePredefinies.setIdMessagePredefini(rs.getLong(1));
			messagePredefinies.setIdSalleVirtuelle(rs.getLong(2));
			messagePredefinies.setLibelleMessagePredefini(rs.getString(3));
			messagePredefinies.setCouleurMessagePredefini(rs.getString(4));
			list.add(messagePredefinies);
		}
		return list;
	}
	//Metode permet de retouner tous les message pr�definies par idSalle
	public static ArrayList<MessagePredefini> getAllMessagePredefinies(long idSalle) throws SQLException {
		ArrayList<MessagePredefini> list = new ArrayList<>();
		Connection conn = Connexion.getConnection();
		String selectSQL = "SELECT * FROM messagePredefini WHERE idSalleVirtuelle = ? ";
		PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
		preparedStatement.setLong(1, idSalle);
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {
			MessagePredefini messagePredefinies = new MessagePredefini();
			messagePredefinies.setIdMessagePredefini(rs.getLong(1));
			messagePredefinies.setIdSalleVirtuelle(rs.getLong(2));
			messagePredefinies.setLibelleMessagePredefini(rs.getString(3));
			messagePredefinies.setCouleurMessagePredefini(rs.getString(4));
			list.add(messagePredefinies);
		}
		return list;
	}
}
