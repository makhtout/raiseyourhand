package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import beans.Question;

public class QuestionDao {
	// Methode d'ajout des questions
	public static void ajouterQuestion(long idSallevirtuelle, String libelleQuestion, String ressourceGraphique)
			throws SQLException {

		Connection conn = Connexion.getConnection();
		String insertTableSQL = "INSERT INTO question"
				+ "(idSalleVirtuelle, libelleQuestion, ressourceGraphique) VALUES" + "(?,?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(insertTableSQL);
		preparedStatement.setLong(1, idSallevirtuelle);
		preparedStatement.setString(2, libelleQuestion);
		preparedStatement.setString(3, ressourceGraphique);
		preparedStatement.executeUpdate();

	}

	// Metode d'obtention de la question � partir de son libelle
	public static long getIdQuestionByLibelle(String libelle) throws SQLException {
		long idQuestion = 0;
		Connection conn = Connexion.getConnection();
		String selectSQL = "SELECT * FROM question WHERE libelleQuestion = ? ";
		PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
		preparedStatement.setString(1, libelle);
		ResultSet rs = preparedStatement.executeQuery();
		Question p = new Question();

		while (rs.next()) {
			p.setIdQuestion(rs.getLong(1));
			p.setIdSalleVirtuelle(rs.getLong(2));
			p.setLibelleQuestion(rs.getString(3));
		}
		idQuestion = p.getIdQuestion();
		return idQuestion;

	}

	// Metode d'obtention de la question � partir de son id
	public static Question getLibelleQuestionById(long idQuestion) throws SQLException {
		Connection conn = Connexion.getConnection();
		String selectSQL = "SELECT * FROM question WHERE idQuestion = ? ";
		PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
		preparedStatement.setLong(1, idQuestion);
		ResultSet rs = preparedStatement.executeQuery();
		Question p = new Question();
		while (rs.next()) {
			p.setIdQuestion(rs.getLong(1));
			p.setIdSalleVirtuelle(rs.getLong(2));
			p.setLibelleQuestion(rs.getString(3));
			p.setRessourceGraphique(rs.getString(4));
		}
		return p;
	}

	// Metode d'obtention des questions propre � une salle � partir del'id de la
	// salle virtuelle
	public static ArrayList<Question> getAllQuestionsByIdSalleVirtuelle(long idSalleVirtuelle) throws SQLException {

		ArrayList<Question> list = new ArrayList<>();
		Connection conn = Connexion.getConnection();
		String sql = "select * from question where idSalleVirtuelle =? ;";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);

		preparedStatement.setLong(1, idSalleVirtuelle);

		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {
			Question p = new Question();
			p.setIdQuestion(rs.getLong(1));
			p.setIdSalleVirtuelle(rs.getLong(2));
			p.setLibelleQuestion(rs.getString(3));
			p.setRessourceGraphique(rs.getString(4));
			list.add(p);
		}
		return list;
	}

	// Methode de suppression d'une question � partir son id
	public static void supprimerQuestionByIdQuestion(long idQuestion) throws SQLException {
		String deleteSQL = "DELETE from question WHERE idQuestion = ?";
		Connection conn = Connexion.getConnection();
		PreparedStatement preparedStatement = conn.prepareStatement(deleteSQL);
		preparedStatement.setLong(1, idQuestion);
		preparedStatement.executeUpdate();
	}



}
