package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import beans.*;

public class UtilisateurDao {
	// Ajout d'un nouvelle utilisateur
	public static void ajouterUtilisateur(Utilisateur util) throws SQLException {

		Connection conn = Connexion.getConnection();
		String insertTableSQL = "INSERT INTO utilisateur"
				+ "(civiliteUtilisateur, pseudoUtilisateur, nomUtilisateur, prenomUtilisateur, mailUtilisateur,mdpUtilisateur) VALUES"
				+ "(?,?,?,?,?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(insertTableSQL);
		preparedStatement.setString(1, util.getCiviliteUtilisateur());
		preparedStatement.setString(2, util.getPseudoUtilisateur());
		preparedStatement.setString(3, util.getNomUtilisateur());
		preparedStatement.setString(4, util.getPrenomUtilisateur());
		preparedStatement.setString(5, util.getMailUtilisateur());
		preparedStatement.setString(6, util.getMdpUtilisateur());
		preparedStatement.executeUpdate();
	}
	// Verifier t'existance de l'utilisateur � partir son pseudo et son mot de passe
	public static Utilisateur verifierUtilisateur(String pseudo, String mdp) throws SQLException {
		Utilisateur util = null;
		Connection conn = Connexion.getConnection();
		String selectSQL = "SELECT * FROM utilisateur WHERE pseudoUtilisateur = ?  and mdpUtilisateur=?";
		PreparedStatement preparedStatement = conn.prepareStatement(selectSQL);
		preparedStatement.setString(1, pseudo);
		preparedStatement.setString(2, mdp);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			long idUtilisateur = rs.getLong(1);
			String civiliteUser = rs.getString(2);
			String pseudoUser = rs.getString(3);
			String nomUtilisateur = rs.getString(4);
			String prenomUtilisateur = rs.getString(5);
			String mailUtilisateur = rs.getString(6);
			String mdpUtilisateur = rs.getString(7);
			util = new Utilisateur(idUtilisateur, pseudoUser, civiliteUser, nomUtilisateur, prenomUtilisateur,
					mailUtilisateur, mdpUtilisateur);

		}
		return util;
	}

}
