package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import beans.ReponseJuste;

public class ReponseJusteDao {
	// Ajouter le(s) reponse(s) justes d'une question
	public static void ajouterReponseJuste(long idQuestion, String libelleReponseJuste) throws SQLException {
		Connection conn = Connexion.getConnection();
		String insertTableSQL = "INSERT INTO reponseJuste" + "(idQuestion, libelleReponseJuste) VALUES" + "(?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(insertTableSQL);
		preparedStatement.setLong(1, idQuestion);
		preparedStatement.setString(2, libelleReponseJuste);
		preparedStatement.executeUpdate();

	}

	// Obtenir les reponses juste d'une question
	public static ReponseJuste getReponseJusteParIdQuestion(long idQuestion) throws SQLException {
		ReponseJuste reponseJuste = new ReponseJuste();
		Connection conn = Connexion.getConnection();
		String sql = "select * from reponsejuste where idQuestion = ? ;";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setLong(1, idQuestion);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			reponseJuste.setIdReponseJuste(rs.getLong(1));
			reponseJuste.setIdQuestion(rs.getLong(2));
			reponseJuste.setLibelleReponseJuste(rs.getString(3));
		}
		return reponseJuste;
	}

}
