package dao;

import java.sql.*;
//Classe de connection avc la base des donn�es de raise your Hand 
public class Connexion {
	private static Connection connection;
	static{
		 try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost/raiseYourHand","root","");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection() {
		return connection;
	}
}